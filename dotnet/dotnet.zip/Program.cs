using System;

namespace HelloWorldSample {
  public static class Program {
    public static void Main() {
      Console.WriteLine("Hello, World!");
    }
  }
}